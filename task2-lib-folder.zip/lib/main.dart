import 'package:flutter/material.dart';
import 'package:task2/my_list_screen.dart';

void main() {
  runApp(MaterialApp(
    home: MyListScreen(),
  ));
}
