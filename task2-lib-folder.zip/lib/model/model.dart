class ListItem {
  final String action;
  final String dueTime;
  final String dueDate;

  ListItem({
    required this.action,
    required this.dueTime,
    required this.dueDate,
  });
}
