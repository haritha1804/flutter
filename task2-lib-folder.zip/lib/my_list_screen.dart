/*class ListItem {
  final String action;
  final String dueTime;
  final String dueDate;

  ListItem({
    required this.action,
    required this.dueTime,
    required this.dueDate,
  });
}*/

import 'package:flutter/material.dart';
import 'package:task2/model/model.dart';
import 'package:task2/task_detail_screen.dart';

class MyListScreen extends StatelessWidget {
  final List<ListItem> items = [
    ListItem(action: 'Task 1', dueTime: '9:00 AM', dueDate: '2024-06-15'),
    ListItem(action: 'Task 2', dueTime: '2:00 PM', dueDate: '2024-06-16'),
    ListItem(action: 'Task 3', dueTime: '11:00 AM', dueDate: '2024-06-17'),
  ];

  MyListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My List'),
      ),
      body: ListView.builder(
        itemCount: items.length,
        itemBuilder: (context, index) {
          final item = items[index];
          return ListTile(
            title: Text(item.action),
            subtitle: Text('Due: ${item.dueTime} on ${item.dueDate}'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => TaskDetailScreen(item: item),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
