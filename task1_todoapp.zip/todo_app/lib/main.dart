import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ToDo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  const MyHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ToDo'),
        backgroundColor: Colors.pink,
        titleTextStyle: const TextStyle(
            color: Colors.white, fontSize: 30, fontWeight: FontWeight.bold),
      ),
      body: Container(
        color: Colors
            .lightBlueAccent, // Background color applied to the entire body
        child: const Center(
            child: Column(
          children: <Widget>[
            Text("this is todo app", style: TextStyle(fontSize: 34)),
            TextField(
              decoration: InputDecoration(labelText: "enter activity"),
            ),
          ],
        )),
      ),
    );
  }
}
